// File Layout
// Datatype   Data item
// UTF        Student Name
// Integer    Student number
// Double     Grade in class 1
// Double     Grade in class 2
// Double     Grade in class 3
// Double     Grade in class 4

import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.util.*;

/**
 * BytePe1 - Starter class for Day 16 Exercises
 * Reads file, counts records, sums values, adds to ArrayList.
 * At end reports out these values.
 * @author  D. Patric
 * @version 2205
 */
 
public class BytePe1 extends Application
{
   // Basic window parts
   Stage stage;
   Scene scene;
   
   // GUI Components
   private TextArea taOutput = new TextArea();
   private TextField tfFileName = new TextField("integer1.dat");
   private ArrayList<Integer> list = new ArrayList<Integer>();
   
   // Other attributes
   private int countRead = 0;
   private int sumRead = 0;
   
	/** Main program */
   public static void main(String [] args)
	{
      launch(args);
   }
   
   /** constructor */
   public void start(Stage _stage) {
      // Setup the window
      stage = _stage;
      stage.setTitle("BytePe1");
      VBox root = new VBox();
      
      // Text field in Top
      FlowPane fpTop = new FlowPane(8,8);
      fpTop.setAlignment(Pos.CENTER);
      fpTop.getChildren().addAll(new Label("File name: "), tfFileName);
      tfFileName.setDisable(true);
      root.getChildren().add(fpTop);
      
      // Text area in CENTER
      root.getChildren().add(taOutput);
      
      // Set font to monospaces
      Font font = taOutput.getFont();
      taOutput.setFont(Font.font("MONOSPACED"));
      
      scene = new Scene(root, 250, 100);
      stage.setScene(scene);
      stage.show();
      
      doWork();
   }
   
   public void doWork() {
   }
}