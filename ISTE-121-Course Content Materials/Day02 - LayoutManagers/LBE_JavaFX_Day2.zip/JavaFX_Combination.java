/**
* JavaFX FlowPane and BorderPane Layout Manager, final example
* 
* @author David Patric, Alan Mutka
* @version 2205
*/

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.*;
import javafx.geometry.*;

public class JavaFX_Combination extends Application implements EventHandler<ActionEvent>{
   
    
   public static void main(String[] args){
      //method inside the Application class,  it will setup our program as a JavaFX application 
      //then the JavaFX is ready, the "start" method will be called automatically  
      launch(args);
   }
   
   @Override
   public void start(Stage _stage) throws Exception{
     
      /////////////////////////Setting window properties
      //set the window title
      _stage.setTitle("Welcome to JavaFX");
   
      //HBox root layout with 8 pixels spacing
      VBox root = new VBox(8);
      
      //create a scene with a specific size (width, height), connnect with the layout
      Scene scene = new Scene(root, 500,250);
      
      //create flow pane
      FlowPane topPane = new FlowPane(8, 8);
      FlowPane midPane = new FlowPane(8, 8);
      
      //*********************************create components
      //TextField is singe line, TextArea multiline
      // Top Components
      Label lblServer = new Label("Server");
      TextField tfServer = new TextField();
      Button btnConnect = new Button("Connect");
      
       // Set up the topPane
      topPane.getChildren().addAll(lblServer, tfServer, btnConnect);
      
   
      // Middle Components
      Label lblToSend = new Label("To Send");
      TextField tfToSend = new TextField();
      Button btnSend = new Button("Send");
      
      // set up midPane
      midPane.getChildren().addAll(lblToSend, tfToSend, btnSend);

   
      // Bottom component
      TextArea taLog = new TextArea();
      
   
      //link to root
      root.getChildren().addAll(topPane,midPane,taLog);
     
      
      //connect stage with the Scene and show it, finalization
      _stage.setScene(scene);
      _stage.show();
      
   }
   
   public void handle(ActionEvent evt){
      System.out.println("YEAP!");
   }
}