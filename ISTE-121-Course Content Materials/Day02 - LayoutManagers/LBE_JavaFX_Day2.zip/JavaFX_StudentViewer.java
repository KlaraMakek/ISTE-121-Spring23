/**
* JavaFX FlowPane and BorderPane Layout Manager, final example
* 
* @author David Patric, Alan Mutka
* @version 2205
*/

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.control.Alert.*;  
import java.io.*;


public class JavaFX_StudentViewer extends Application implements EventHandler<ActionEvent>{
   
   
   private final String sFileName = "Students.csv";
   
   TextField tfName;
   TextField tfID;
   TextField tfMajor;
   TextField tfGPA;
    
   public static void main(String[] args){
      //method inside the Application class,  it will setup our program as a JavaFX application 
      //then the JavaFX is ready, the "start" method will be called automatically  
      launch(args);
   }
   
   @Override
   public void start(Stage _stage) throws Exception{
     
      /////////////////////////Setting window properties
      //set the window title
      _stage.setTitle("Welcome to JavaFX");
   
      //HBox root layout with 8 pixels spacing
      VBox root = new VBox(8);
      
      //create a scene with a specific size (width, height), connnect with the layout
      Scene scene = new Scene(root, 300,150);
      
      //create flow pane
      GridPane topPane = new GridPane();
      topPane.setHgap(10);
      topPane.setVgap(5);
      
      FlowPane midPane = new FlowPane(8, 8);
      midPane.setAlignment(Pos.CENTER_RIGHT);
  
      
      //*********************************create components
      //TextField is singe line, TextArea multiline
      // Top Components
      Label lblName = new Label("Name:");
      tfName = new TextField();
      topPane.addRow(0,lblName, tfName);//we can add rows directly
      
      Label lblID = new Label("ID:");
      tfID = new TextField();
      topPane.addRow(1,lblID, tfID);//we can add rows directly
      
      Label lblMajor = new Label("Major:");
      tfMajor = new TextField();
      topPane.addRow(2,lblMajor, tfMajor);//we can add rows directly
      
      Label lblGPA = new Label("GPA:");
      tfGPA = new TextField();
      topPane.addRow(3,lblGPA, tfGPA);//we can add rows directly

      
     
   
      // Middle Components
      Button btnNext = new Button("Save");
      Button btnExit = new Button("Exit");
      
      // set up midPane
      midPane.getChildren().addAll(btnNext, btnExit);

   
      //link to root
      root.getChildren().addAll(topPane,midPane);
      
      //add events
      btnNext.setOnAction(this);
      btnExit.setOnAction(this);

     
      
      //connect stage with the Scene and show it, finalization
      _stage.setScene(scene);
      _stage.show();
      
   }
   
   private void write()
   {
      try {
            
         PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(sFileName), true)));
               
         //get text
         String name = tfName.getText();
         String id = tfID.getText();
         String major = tfMajor.getText();
         String amount = tfGPA.getText();
         pr.printf("%s, %s, %s, %s", name, id,major,amount); 
         pr.println();//important to change line
         pr.close();
         
         Alert alert = new Alert(AlertType.INFORMATION);         
         alert.setTitle("Information Dialog");
         alert.setHeaderText("Information");
         alert.setContentText("Writing was successful!");
         alert.showAndWait();

      
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   
   public void handle(ActionEvent evt){
      System.out.println("YEAP!");
      
      Button btn = (Button)evt.getSource();
      switch(btn.getText()){
         case "Save":
            write();
            break;
        case "Exit":
            System.out.println("EXIT!");
            System.exit(0);
            break;
      }

   }
}