/**
* JavaFX FlowPane and BorderPane Layout Manager, final example
* 
* @author David Patric, Alan Mutka
* @version 2205
*/

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.*;
import javafx.geometry.*;

public class JavaFX_HBOX extends Application implements EventHandler<ActionEvent>{
   
    
   public static void main(String[] args){
      //method inside the Application class,  it will setup our program as a JavaFX application 
      //then the JavaFX is ready, the "start" method will be called automatically  
      launch(args);
   }
   
   @Override
   public void start(Stage _stage) throws Exception{
     
      /////////////////////////Setting window properties
      //set the window title
      _stage.setTitle("Welcome to JavaFX");
   
      //HBox root layout with 8 pixels spacing
      HBox root = new HBox(8);
      
      //create a scene with a specific size (width, height), connnect with the layout
      Scene scene = new Scene(root, 600,50);
      
      Label lblName = new Label("Name");
      Label lblID = new Label("ID");
      Label lblGPA = new Label("GPA");
   
      TextField tfName = new TextField();
      TextField tfID = new TextField();
      TextField tfGPA = new TextField();
      
      root.getChildren().addAll(lblName,tfName,lblID,tfID,lblGPA, tfGPA);
     
      
      //connect stage with the Scene and show it, finalization
      _stage.setScene(scene);
      _stage.show();
      
   }
   
   public void handle(ActionEvent evt){
      System.out.println("YEAP!");
   }
}