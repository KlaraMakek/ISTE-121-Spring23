import java.net.*;
import java.io.*;
import java.util.*;

																								

public class MyMThreadServerForFiles{				

   // Socket stuff
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 32001;		
   int clientCounter=1;																		
   
   public MyMThreadServerForFiles(){
      
      System.out.println("MThread started...");
      ServerThread  serverThread = new ServerThread();
      serverThread.start();
   }
   
   class ServerThread extends Thread{
      public void run(){
         try {
            sSocket = new ServerSocket(SERVER_PORT);
         }
         catch(IOException ioe) {
            System.out.println("IO Exception (1): "+ ioe + "\n");
            return;
         }
         
         while(true){
            Socket cSocket = null;
            try {
               System.out.println("Waiting client to connect...");
            // Wait for a connection
               cSocket = sSocket.accept();
            }
            catch(IOException ioe) {
               System.out.println("IO Exception (2): "+ ioe + "\n");
               return;
            }
            //Start client thread
            ClientThread ct = new ClientThread(cSocket, "Client" + clientCounter);
            clientCounter++;
            ct.start();  
         }
      
      }
   }//end of ServerThread
   
   //client thread
   class ClientThread extends Thread{
      private Socket cSocket=null;
      private String cName="";
      public ClientThread(Socket _cSocket, String _name){
         this.cSocket = _cSocket;
         this.cName = _name;
      }
      public void run(){
         System.out.println(this.cName +" connected");
         DataInputStream dis = null;
         DataOutputStream dos = null;         
         try {
            dos = new DataOutputStream(cSocket.getOutputStream());
            dis = new DataInputStream(cSocket.getInputStream());
            
            while(true) {
            
            
               String command = dis.readUTF();
            
               switch (command.toUpperCase()) {
                  case "NAMES":
                     dos.writeInt(5);
                     dos.writeUTF("PERO");
                     dos.writeUTF("ANTE");
                     dos.writeUTF("STIPE");
                     dos.writeUTF("BRANKO");
                     dos.writeUTF("ALAN");
                     dos.flush();
                     break;
                  case "DIR":
                     String currentDir = new File(".").getCanonicalPath();
                     File curDir = new File(currentDir);
                     File[] list = curDir.listFiles();
                     dos.writeInt(list.length + 1);
                     dos.writeUTF("Listing of: " + currentDir);
                     for (File f : list) {
                        dos.writeUTF(f.getName());
                     }
                     dos.flush();
                     break;
                  case "UPLOAD":
                     String fileName = dis.readUTF();
                     System.out.println("Writing..." + fileName);
                     DataOutputStream fos = new DataOutputStream(new FileOutputStream(new File(fileName)));
                     long fLen = dis.readLong();         // get the file length
                     for (long i = 0; i < fLen; i++) {   // read and store the file byte-by-byte
                        byte b = dis.readByte();
                        fos.writeByte(b);
                     }
                  // close the file
                     fos.close();  
                     break;
               
               }
              
            }
         
                               
         }
         catch(Exception e) {
            System.out.println("Exception opening streams: " + e);
            System.out.println(this.cName+" disconnected");
         }
         
         try{
            dos.close();
            dis.close();
            this.cSocket.close();
         }
         catch(IOException ie){
         }
      
              
      }
   }
   
   
   public static void main(String [] args) {															
      new MyMThreadServerForFiles();
   }
                     															
}	// end class																								
					
					
					
