import java.net.*;
import java.io.*;
import java.util.*;

																								

public class MyMThreadServer{				

   // Socket stuff
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 32001;		
   int clientCounter=1;																		
   
   public MyMThreadServer(){
      
      System.out.println("MThread started...");
      ServerThread  serverThread = new ServerThread();
      serverThread.start();
   }
   
   class ServerThread extends Thread{
      public void run(){
         try {
            sSocket = new ServerSocket(SERVER_PORT);
         }
         catch(IOException ioe) {
            System.out.println("IO Exception (1): "+ ioe + "\n");
            return;
         }
         
         while(true){
            Socket cSocket = null;
            try {
               System.out.println("Waiting client to connect...");
            // Wait for a connection
               cSocket = sSocket.accept();
            }
            catch(IOException ioe) {
               System.out.println("IO Exception (2): "+ ioe + "\n");
               return;
            }
            //Start client thread
            ClientThread ct = new ClientThread(cSocket, "Client" + clientCounter);
            clientCounter++;
            ct.start();  
         }
      
      }
   }//end of ServerThread
   
   //client thread
   class ClientThread extends Thread{
      private Socket cSocket=null;
      private String cName="";
      public ClientThread(Socket _cSocket, String _name){
         this.cSocket = _cSocket;
         this.cName = _name;
      }
      public void run(){
         System.out.println(this.cName +" connected");
         PrintWriter pwt = null;
         Scanner scn = null;
         try {
            pwt = new PrintWriter(new OutputStreamWriter(cSocket.getOutputStream()));
            scn = new Scanner(new InputStreamReader(cSocket.getInputStream()));
            
            while(true) {
               String line = scn.nextLine();
               System.out.println("Received["+this.cName+"]: " + line);
               line = line.toUpperCase();
               System.out.println("Reply["+this.cName+"]: " + line);
               pwt.println(line); pwt.flush();
            }
         
                               
         }
         catch(Exception e) {
            System.out.println("Exception opening streams: " + e);
            System.out.println(this.cName+" disconnected");
         }
         
         try{
            pwt.close();
            scn.close();
            this.cSocket.close();
         }
         catch(IOException ie){
         }
      
              
      }
   }
   
   
   public static void main(String [] args) {															
      new MyMThreadServer();
   }
                     															
}	// end class																								
					
					
					
