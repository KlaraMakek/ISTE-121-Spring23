import java.net.*;
import java.io.*;
import java.util.*;


/* MyClient - Demo of client / server network communication
	by: Michael Floeser
*/

public class MyClientFILE																				
{															

   //general SOCKET attributes
   public static final int SERVER_PORT = 32001;
   private Socket socket = null;
   
   // IO attributes
   private DataOutputStream dos = null;        // Stream TO server
   private DataInputStream dis = null;         // Stream FROM server

   
   public MyClientFILE(String ipAddress){
      try{																								
      																								
      	// Make a connection with the server												
         socket = new Socket(ipAddress, SERVER_PORT);											
      																									
      	// Open input from server																
         dis = new DataInputStream(socket.getInputStream());
         dos = new DataOutputStream(socket.getOutputStream());      
         
         
         Scanner keyboard = new Scanner(System.in);
         while(true){
            System.out.print("Command:");
            String textToSent = keyboard.nextLine();
            if(textToSent.length()==0) 
               break;
               
            switch(textToSent){
               case "NAMES":
                  dos.writeUTF("NAMES");
                  int nNames = dis.readInt();
                  for (int i = 0; i < nNames; i++) { 
                     String s = dis.readUTF();
                     System.out.println(s);
                  
                  }
                  break;
               case "DIR":
                  dos.writeUTF("DIR");
                  dos.flush();
                  
                  int nFiles = dis.readInt();
                  for (int i = 0; i < nFiles; i++) {
                     String s = dis.readUTF();
                     System.out.println(s);
                  }
                  break;
                  
               case "UPLOAD":
                  dos.writeUTF("UPLOAD");
                  System.out.println("Sending the file: TextToSend.txt");
                  File locFile = new File("TextToSend.txt");
                  DataInputStream fis = new DataInputStream(new FileInputStream(locFile));
                  long fLen = locFile.length();
                  dos.writeUTF("TextToSendCOPY.txt");
                  dos.writeLong(fLen);
                  for (long i = 0; i < fLen; i++) {
                     byte b = fis.readByte();
                     dos.writeByte(b);
                  }
                  dos.flush();
                  fis.close();
               
                  break;
            }
                         
            System.out.println("Sent: " + textToSent);
         }
         socket.close();
         dis.close();
         dos.close();
      																			
      }	
      																								
      catch(UnknownHostException uhe) {														
         System.out.println("no host");														
         uhe.printStackTrace();																	
      }																									
      catch(IOException ioe) {																	
         System.out.println("IO error");														
         ioe.printStackTrace();																	
      }																						
   }
												
   public static void main(String [] args)													
   {																										
      new MyClientFILE("127.0.0.1");																	
   }																										
}																											
