import java.net.*;
import java.io.*;
import java.util.*;


/* MyClient - Demo of client / server network communication
	by: Michael Floeser
*/

public class MyClient																				
{															

   //general SOCKET attributes
   public static final int SERVER_PORT = 32001;
   private Socket socket = null;
   
   // IO attributes
   private PrintWriter pwt = null;
   private Scanner scn = null;

   
   public MyClient(String ipAddress){
      try{																								
      																								
      	// Make a connection with the server												
         socket = new Socket(ipAddress, SERVER_PORT);											
      																									
      	// Open input from server																
         scn = new Scanner(new InputStreamReader(socket.getInputStream()));
         
      																									
      	// open output to server																
         pwt = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
      
         Scanner keyboard = new Scanner(System.in);
         while(true){
            System.out.print("Enter text to send:");
            String textToSent = keyboard.nextLine();
            if(textToSent.length()==0) 
               break;
            pwt.println(textToSent);
            pwt.flush();
              
            System.out.println("Sent: " + textToSent);
         
            //wait for reply
            String reply = scn.nextLine();
            System.out.println("Reply: " + reply);
         
         
         }
         socket.close();
         scn.close();
         pwt.close();
      																			
      }	
      																								
      catch(UnknownHostException uhe) {														
         System.out.println("no host");														
         uhe.printStackTrace();																	
      }																									
      catch(IOException ioe) {																	
         System.out.println("IO error");														
         ioe.printStackTrace();																	
      }																						
   }
												
   public static void main(String [] args)													
   {																										
      new MyClient("127.0.0.1");																	
   }																										
}																											
