import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.io.*;

/**
 * Class WriteFBRoster1
 * A class to read a binary roster of baseball players and display
 * it to the user
 * 
 * @author Pete Lutz
 * @version 7-8-2018
 */
public class WriteTEXT extends Application implements EventHandler<ActionEvent> {
   // Window attributes
   private Stage stage;
   private Scene scene;

   // Text fields
   private TextField tfJersey = new TextField();
   private TextField tfName = new TextField();
   private TextField tfPosition = new TextField();
   private TextField tfDOB = new TextField();
   private TextField tfWeight = new TextField();
   private TextField tfAge = new TextField();
   private TextField tfExperience = new TextField();
   private TextField tfCollege = new TextField();

   // Create Arrays of textfields, labels and set the desired textfield width
   private TextField[] tfAll = { tfJersey, tfName, tfPosition, tfDOB, tfWeight,
         tfAge, tfExperience, tfCollege };
   private String[] tfLabels = { "Jersey  ", "Name  ", "Position  ", "Birthday  ", "Weight  ",
         "Age  ", "Experience  ", "College  " };
   private int[] tfWidths = { 3, 10, 3, 5, 5, 2, 2, 10 };

   // Buttons
   private Button btnWrite = new Button("Write");
   private Button btnQuit = new Button("Quit");

   // Checkbox
   CheckBox cbAppend = new CheckBox("Append");

   // File IO attributes
   public static final String FILE_NAME = "FBRosterTextOut_FX.txt";

   /** main program */
   public static void main(String[] args) {
      launch(args);
   }

   /** Constructor */
   public void start(Stage _stage) {
      // Set up window
      stage = _stage;
      stage.setTitle("Football Roster Text Writer");
      VBox root = new VBox(8);

      // Make the Top a GridPane that is 2x whatever
      // Col 1 is a label and Col 2 is a text field on each row
      GridPane gpTop = new GridPane();
      for (int i = 0; i < tfAll.length; i++) {
         Label label = new Label(tfLabels[i]);
         gpTop.setHalignment(label, HPos.RIGHT);
         gpTop.setFillWidth(tfAll[i], false);// set if the control needs to fill the whole width
         tfAll[i].setPrefColumnCount(tfWidths[i]);
         gpTop.addRow(i, label, tfAll[i]);
      }
      root.getChildren().add(gpTop);

      // check the AppendBox
      cbAppend.setSelected(true);

      // The Bottom will have the navigation buttons
      FlowPane fpBot = new FlowPane(8, 8);
      fpBot.setAlignment(Pos.CENTER);
      fpBot.getChildren().addAll(btnWrite, btnQuit, cbAppend);
      root.getChildren().add(fpBot);

      // Catch button clicks
      btnWrite.setOnAction(this);
      btnQuit.setOnAction(this);

      // Set scene and show window
      scene = new Scene(root, 300, 250);
      stage.setScene(scene);
      stage.show();
   }

   /** ActionEvent handler */
   public void handle(ActionEvent ae) {
      String label = ((Button) ae.getSource()).getText();

      switch (label) {
         case "Write":
            writeRecord();
            break;
         case "Quit":
            System.exit(1);
            break;
      }
   }

   public void writeRecord() {
      int jersey = Integer.parseInt(tfJersey.getText());
      String name = tfName.getText();
      String position = tfPosition.getText();
      String dob = tfDOB.getText();
      double weight = Double.parseDouble(tfWeight.getText());
      int age = Integer.parseInt(tfAge.getText());
      String experience = tfExperience.getText();
      String college = tfCollege.getText();

      // open, write (append) and close

      // Open the file for writing
      // Read in and display the first record
      try {

         // open text file

      } catch (IOException ioe) {
         Alert alert = new Alert(AlertType.ERROR, "Cannot open file " + FILE_NAME + "\n" + ioe);
         alert.showAndWait();
         System.exit(1);
      }
   }
}