import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.io.*;
import java.util.*;

/**
 * Class ReadFBRoster
 * A class to read a binary roster of baseball players and display
 * it to the user
 * 
 * @author Pete Lutz
 * @version 7-8-2018
 */
public class ReadText extends Application implements EventHandler<ActionEvent> {
   // Window attributes
   private Stage stage;
   private Scene scene;

   // Text fields
   private TextField tfJersey = new TextField();
   private TextField tfName = new TextField();
   private TextField tfPosition = new TextField();
   private TextField tfDOB = new TextField();
   private TextField tfWeight = new TextField();
   private TextField tfAge = new TextField();
   private TextField tfExperience = new TextField();
   private TextField tfCollege = new TextField();
   private TextField[] tfAll = { tfJersey, tfName, tfPosition, tfDOB, tfWeight,
         tfAge, tfExperience, tfCollege };
   private String[] tfLabels = { "Jersey  ", "Name  ", "Position  ", "Birthday  ", "Weight  ",
         "Age  ", "Experience  ", "College  " };
   private int[] tfWidths = { 3, 10, 3, 5, 5, 2, 2, 10 };

   // Buttons
   private Button btnRewind = new Button("Rewind");
   private Button btnNext = new Button("Next");
   private Button btnQuit = new Button("Quit");

   // File IO attributes
   public static final String FILE_NAME = "FBRosterText.txt";

   /** main program */
   public static void main(String[] args) {
      launch(args);
   }

   /** Constructor */
   public void start(Stage _stage) {
      // Set up window
      stage = _stage;
      stage.setTitle("Football Roster");
      VBox root = new VBox(8);

      // Make the Top a GridPane that is 2x whatever
      // Col 1 is a label and Col 2 is a text field on each row
      GridPane gpTop = new GridPane();
      for (int i = 0; i < tfAll.length; i++) {
         Label label = new Label(tfLabels[i]);
         gpTop.setHalignment(label, HPos.RIGHT);
         gpTop.setFillWidth(tfAll[i], false);
         tfAll[i].setPrefColumnCount(tfWidths[i]);
         tfAll[i].setEditable(false);
         gpTop.addRow(i, label, tfAll[i]);
      }
      root.getChildren().add(gpTop);

      // The Bottom will have the navigation buttons
      FlowPane fpBot = new FlowPane(8, 8);
      fpBot.setAlignment(Pos.CENTER);
      fpBot.getChildren().addAll(btnRewind, btnNext, btnQuit);
      root.getChildren().add(fpBot);

      // Set the handler for the buttons
      btnNext.setOnAction(this);
      btnRewind.setOnAction(this);
      btnQuit.setOnAction(this);

      // Open the file for reading
      // Read in and display the first record
      try {

      } catch (IOException ioe) {
         Alert alert = new Alert(AlertType.ERROR, "Cannot open file " + FILE_NAME + "\n" + ioe);
         alert.showAndWait();
         System.exit(1);
      }
      readNext();

      // Set scene and show window
      scene = new Scene(root, 250, 250);
      stage.setScene(scene);
      stage.show();
   }

   /** ActionEvent handler */
   public void handle(ActionEvent ae) {
      String command = ((Button) ae.getSource()).getText();

      switch (command) {
         case "Rewind":
            try {

            } catch (IOException ioe) {
               Alert alert = new Alert(AlertType.ERROR, "Cannot open file " + FILE_NAME + "\n" + ioe);
               alert.showAndWait();
               System.exit(1);
            }
            readNext();
            break;
         case "Next":
            readNext();
            break;
         case "Quit":
            System.exit(0);
            break;
      }
   }

   /* readNext ... read next record */
   public void readNext() {
      // variable for each field
      int jersey = 0;
      String name = null;
      String position = null;
      String dob = null;
      double weight = 0.0;
      int age = 0;
      String experience = null;
      String college = null;

      // read in a record
      try {
         if () {
           
         } else {
            Alert alert = new Alert(AlertType.ERROR, "End of Data: " + FILE_NAME);
            alert.showAndWait();
            return;
         }
      } catch (Exception ioe) {
         Alert alert = new Alert(AlertType.ERROR, "Error reading " + FILE_NAME + "\n" + ioe);
         alert.showAndWait();
         System.exit(1);
      }

      // post the results
      tfJersey.setText("" + jersey);
      tfName.setText(name);
      tfPosition.setText(position);
      tfDOB.setText(dob);
      tfWeight.setText(String.format("%3.2f", weight));
      tfAge.setText("" + age);
      tfExperience.setText(experience);
      tfCollege.setText(college);
   }
}