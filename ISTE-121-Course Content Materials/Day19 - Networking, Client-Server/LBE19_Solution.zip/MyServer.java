import java.net.*;
import java.io.*;
import java.util.*;

																								

public class MyServer{				

   // Socket stuff
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 32001;																				
   
   public MyServer(){
      doServerWork();
   }
   
    /** doServerWork - does the basic non-GUI work of the server */
   public void doServerWork() {
      
      System.out.println("Waiting client to connect...");
      // Claim the port and start listening for new connections
      try {
         sSocket = new ServerSocket(SERVER_PORT);
      }
      catch(IOException ioe) {
         System.out.println("IO Exception (1): "+ ioe + "\n");
         return;
      }
   
      // Socket for comm with client      
      Socket cSocket = null;
      try {
         // Wait for a connection
         cSocket = sSocket.accept();
      }
      catch(IOException ioe) {
          System.out.println("IO Exception (2): "+ ioe + "\n");
         return;
      }
      
      // No real processing yet
       System.out.println("Client connected!\n");
   
      PrintWriter pwt = null;
      Scanner scn = null;
      try {
         pwt = new PrintWriter(new OutputStreamWriter(cSocket.getOutputStream()));
         scn = new Scanner(new InputStreamReader(cSocket.getInputStream()));
      }
      catch(Exception e) {
          System.out.println("Exception opening streams: " + e + "]n");
      }
      
      while(scn.hasNextLine()) {
         String line = scn.nextLine();
         System.out.println("Received: " + line + "\n");
         line = line.toUpperCase();
         System.out.println("Replying: " + line +"\n");
         pwt.println(line); pwt.flush();
      }
      
      try {
         pwt.close();
         scn.close();
      }
      catch(Exception e) {
          System.out.println("Exception closing streams: " + e + "\n");
      }            
   }   

   
   public static void main(String [] args) {															
      new MyServer();
   }
                     															
}	// end class																								
					
					
					
