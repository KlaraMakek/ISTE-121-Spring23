import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * TCPServer - This is a fairly complete server. Only allows single connections, 
 * but receives messages and sends a reply.
 * @author  D. Patric
 * @version 2205
 */
public class TCPServer1 extends Application {
   // Window attributes
   private Stage stage;
   private Scene scene;
   private VBox root;
   
   // GUI Components
   public Label lblLog = new Label("Log:");
   public TextArea taLog = new TextArea();
   
   // Socket stuff
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 32001;
   
   /**
    * main program
    */
   public static void main(String[] args) {
      launch(args);
   }
   
   /**
    * Launch, draw and set up GUI
    * Do server stuff
    */
   public void start(Stage _stage) {
      // Window setup
      stage = _stage;
      stage.setTitle("TCPServer1");
      stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
         public void handle(WindowEvent evt) { System.exit(0); }
      });
      stage.setResizable(false);
      root = new VBox(8);
   
      // LOG components
      FlowPane fpLog = new FlowPane(8,8);
      fpLog.setAlignment(Pos.CENTER);
      taLog.setPrefRowCount(10);
      taLog.setPrefColumnCount(35);
      fpLog.getChildren().addAll(lblLog, taLog);
      root.getChildren().add(fpLog);
      
      // Show window
      scene = new Scene(root, 475, 200);
      stage.setScene(scene);
      stage.show();      
      
      // Do server work in a thread
      Thread t = new Thread() {
         public void run() { doServerWork(); }
      };
      t.start();
   }
   
   /** doServerWork - does the basic non-GUI work of the server */
   public void doServerWork() {
      // Claim the port and start listening for new connections
      try {
         sSocket = new ServerSocket(SERVER_PORT);
      }
      catch(IOException ioe) {
         taLog.appendText("IO Exception (1): "+ ioe + "\n");
         return;
      }

      // Socket for comm with client      
      Socket cSocket = null;
      try {
         // Wait for a connection
         cSocket = sSocket.accept();
      }
      catch(IOException ioe) {
         taLog.appendText("IO Exception (2): "+ ioe + "\n");
         return;
      }
      
      // No real processing yet
      taLog.appendText("Client connected!\n");

      PrintWriter pwt = null;
      Scanner scn = null;
      try {
         pwt = new PrintWriter(new OutputStreamWriter(cSocket.getOutputStream()));
         scn = new Scanner(new InputStreamReader(cSocket.getInputStream()));
      }
      catch(Exception e) {
         taLog.appendText("Exception opening streams: " + e + "]n");
      }
      
      while(scn.hasNextLine()) {
         String line = scn.nextLine();
         taLog.appendText("Received: " + line + "\n");
         line = line.toUpperCase();
         taLog.appendText("Replying: " + line + "\n");
         pwt.println(line); pwt.flush();
      }
      
      try {
         pwt.close();
         scn.close();
      }
      catch(Exception e) {
         taLog.appendText("Exception closing streams: " + e + "\n");
      }            
   }   
}