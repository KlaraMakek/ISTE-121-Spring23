import java.io.*;
import java.util.*;

public class StudentDatabaseSearchStarter {

    private final static String OUTPUT_NAME = "STUDENTS";

    private ArrayList<String> studentNames = new ArrayList<String>();// final array of names
    private ArrayList<Double> studentGrades = new ArrayList<Double>();// final aray of grades
    private ArrayList<String> databaseNames = new ArrayList<String>();// final array of source files
    Object lock = new Object();

    public static void main(String args[]) {
        new StudentDatabaseSearch();
    }

    StudentDatabaseSearchStarter() {
        // preparing threads
        // creating runnable threads - each thread demands FILEPATH and grande range

    }

    class SearchGrades extends Thread {

    }

}
