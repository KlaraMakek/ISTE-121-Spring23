import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;

/**
 * Simple thread ... update a time counter while the user
 * types in data to store in a text file
 * @author Pete Lutz
 * @version 7-9-2018
 */

public class ClockTimer extends Application implements EventHandler<ActionEvent> {
   // Window attributes
   private Stage stage;
   private Scene scene;
   
   // GUI Components
   private TextField tfTimer = new TextField("00:00");
   private TextField tfCounter = new TextField();
   private Button btnInc = new Button("+");
   
   // Counter attribute
   private int count = 0;
   
   /** main program */
   public static void main(String[] args) {
      launch(args);
   }
   
   /** constructor*/
   public void start(Stage _stage) {
      // Setup window
      stage = _stage;
      stage.setTitle("Counter");
      
      VBox root = new VBox(8);
      
      // Timer in Top
      FlowPane fpTop = new FlowPane(8,8);
      fpTop.setAlignment(Pos.CENTER_RIGHT);
      tfTimer.setPrefColumnCount(5);
      fpTop.getChildren().add(tfTimer);
      tfTimer.setEditable(false);
      root.getChildren().add(fpTop);
      
      // Button and counter in Bottom
      FlowPane fpBot = new FlowPane(8,8);
      fpBot.setAlignment(Pos.CENTER);
      fpBot.getChildren().add(tfCounter);
      tfCounter.setText("" + count);
      tfCounter.setEditable(false);
      fpBot.getChildren().add(btnInc);
      root.getChildren().add(fpBot);
      
      // Setup handler for button
      btnInc.setOnAction(this);
      stage.setOnCloseRequest(
         new EventHandler<WindowEvent>() {
            public void handle(WindowEvent evt) {
               System.exit(0);
            }
         } );
      
      // Set the scene and show the window
      scene = new Scene(root, 300, 75);
      stage.setScene(scene);
      stage.show();
      
   }
   
   /** Button handler */
   public void handle(ActionEvent ae) {
      count++;
      tfCounter.setText("" + count);
   }
   

}