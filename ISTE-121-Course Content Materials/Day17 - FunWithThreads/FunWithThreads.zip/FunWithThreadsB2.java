public class FunWithThreadsB2{

   private String buffer ="";
   private static Object lock = new Object();
   
   FunWithThreadsB2(){
      System.out.println("Main Thread START");
      MyThread t1 = new MyThread("A");
      MyThread t2 = new MyThread("B");
   
      t1.start();
      t2.start();
      
      try{
         t1.join();
         t2.join();
      }
      catch(InterruptedException ie){
         System.out.println(ie);
      }
      System.out.println("Final buffer:" + buffer);
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreadsB2();
   }
   
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
         for(int i=0;i<5;i++){
            try{
               Thread.sleep(1);
            }
            catch(InterruptedException ie){
               System.out.println(ie);
            }
            synchronized(lock)
            {
               buffer = buffer+name;
               System.out.println("Thread:"+this.name +" "+ buffer);
            }
         }
      }
   }
}