//check lock, and withouth lock
public class FunWithThreads6{

   private int counter =0;
   Object lock = new Object();
   FunWithThreads6(){
      System.out.println("Main Thread START");
      MyThread t1 = new MyThread("Thread 1");
      MyThread t2 = new MyThread("Thread 2");
   
      t1.start();
      t2.start();
      
      try{
         t1.join();
         t2.join();
      }
      catch(InterruptedException ie){
         System.out.println(ie);
      }
      System.out.println("Counter= " + counter);
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreads6();
   }
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
        System.out.println(name + "start looping (40000)..."); 
         for(int i=0;i<40000;i++){
           //synchronized(lock){
           counter++;
           //}
         }
         System.out.println(name + "end...");
      }
   }
}