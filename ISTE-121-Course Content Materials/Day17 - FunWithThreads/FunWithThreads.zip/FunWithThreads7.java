import java.util.*;

//check lock, and withouth lock
public class FunWithThreads7{

   private int counter =0;
   int nThread=20;
   Object lock = new Object();
   FunWithThreads7(){
      ArrayList<Thread> arrayOfThreads = new ArrayList<Thread>();
      System.out.println("Starting " + nThread+ "threads");
      for(int i=0;i<nThread;i++){
         MyThread t1 = new MyThread(i+"");
         arrayOfThreads.add(t1);
      }
   
      for(int i=0;i<arrayOfThreads.size();i++){
         arrayOfThreads.get(i).start();
      }
      
      try{
         for(int i=0;i<arrayOfThreads.size();i++){
            arrayOfThreads.get(i).join();
         }
      
      }
      catch(InterruptedException ie){
         System.out.println(ie);
      }
      System.out.println("Counter= " + counter);
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreads7();
   }
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
         System.out.println(name + "start looping (40000)..."); 
         for(int i=0;i<40000;i++){
            synchronized(lock){
               counter++;
            }
         }
         System.out.println(name + "end...");
      }
   }
}