import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.io.*;

/**
 * Name: Dave Patric
 * Course/Section: ISTE-121-02/04
 * Practical #1 - BinaryIO2 - Solution to Problem #2 
 * Date: 02/04/2021
 */

public class FunWithThreads8 extends Application {
   private Stage stage;
   private Scene scene;
   private VBox root = new VBox(8);

   public static void main(String[] args) {
      launch(args);
   }
   
   public void start(Stage _stage) throws Exception {
      stage = _stage;
      stage.setTitle("FunWithThreads Progress");
   
     
      for(int i=0;i<10;i++){
      
         MyHappyFlowPane pane = new MyHappyFlowPane(i*300);
         Thread t = new Thread(pane);
         t.start();
         root.getChildren().add(pane);
      }
      
      
              
      scene = new Scene(root, 200, 200);
      stage.setScene(scene);
      stage.show();
   
   }
   
   class MyHappyFlowPane extends FlowPane implements Runnable{
      ProgressBar bar=new ProgressBar();
      int delay=0;
      
      public MyHappyFlowPane(int delay){
         this.getChildren().add(bar);
         this.delay=delay;
         bar.setProgress(0);
      }
      public void run(){
      
         try{
            Thread.sleep(delay);
         }
         catch(InterruptedException ie){}
      
         for(int i=0;i<100;i++){  
         
            final double finalI= i/100.0;
            Platform.runLater(
               new Runnable() {
                  public void run() {
                  
                     bar.setProgress(finalI);
                  
                  }
               });
         
            try{
               Thread.sleep(20);
            }
            catch(InterruptedException ie){}
         }
         
         for(int i=100;i>=0;i--){
         
            final double finalI= i/100.0;

            Platform.runLater(
               new Runnable() {
                  public void run() {
                  
                     bar.setProgress(finalI);
                  
                  }
               });
         
         
            try{
               Thread.sleep(20);
            }
            catch(InterruptedException ie){}
         }
      
      }
   }
}	
