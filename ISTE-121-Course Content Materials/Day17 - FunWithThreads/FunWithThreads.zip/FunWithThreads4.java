public class FunWithThreads4{

   private int counter =0;
   FunWithThreads4(){
      System.out.println("Main Thread START");
      MyThread t1 = new MyThread("Thread 1");
      MyThread t2 = new MyThread("Thread 2");
   
      t1.start();
      
      t2.start();
      
      try{
         t1.join();
         t2.join();
      }
      catch(InterruptedException ie){
         System.out.println(ie);
      }
      
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreads4();
   }
   
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
         for(int i=0;i<4;i++){
            try{
               Thread.sleep(1000);
            }
            catch(InterruptedException ie){
               System.out.println(ie);
            }
            System.out.println(this.name +" "+ counter);
            counter++;
         
         }
      }
   }
}