public class FunWithThreads2{


   FunWithThreads2(){
      System.out.println("Main Thread START");
      MyThread t1 = new MyThread("Thread 1");
      MyThread t2 = new MyThread("Thread 2");
   
      t1.start();
      t2.start();
      
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreads2();
   }
   
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
         for(int i=0;i<4;i++){
            try{
               Thread.sleep(1000);
            }
            catch(InterruptedException ie){
               System.out.println(ie);
            }
            System.out.println(this.name +" "+ i);
         }
      }
   }
}