public class FunWithThreads1{






   FunWithThreads1(){
      System.out.println("Main Thread START");
      MyThread t1 = new MyThread("Thread 1");
      t1.run();
      
      MyThread t2 = new MyThread("Thread 2");
      t2.run();
      
      System.out.println("Main Thread END");
   }
   public static void main(String[] args){
      new FunWithThreads1();
   }
   
   
   class MyThread extends Thread{
      String name="";
      public MyThread(String name){
         this.name = name;
      }
      @Override
      public void run(){
         for(int i=0;i<4;i++){
            try{
               Thread.sleep(1000);
            }
            catch(InterruptedException ie){
               System.out.println(ie);
            }
         
            System.out.println(this.name +" "+ i);
         }
      }
   }
}