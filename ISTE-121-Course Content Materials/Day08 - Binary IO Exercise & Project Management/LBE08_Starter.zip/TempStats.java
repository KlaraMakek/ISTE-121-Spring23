import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.io.*;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Class TempStats
 * Read in 365 high temperatures for one year in Rochester.
 * The first is Jan 1, the second is Jan 2, ..., the 366th is Dec 31.
 * There is always leap year (Feb 29th) data.
 * @author Pete Lutz, Alan Mutka
 * @version 7-8-2018
 */
 
public class TempStats extends Application implements EventHandler<ActionEvent> {
   // Window attributes
   private Stage stage;
   private Scene scene;
   
   // File GUI components
   
   
   /** main program */
   public static void main(String[] args) {
      launch(args);
   }
   
   /** constructor */
   public void start(Stage _stage) {
      // Setup window
      stage = _stage;
      stage.setTitle("Temperature Statistics");
      VBox root = new VBox(8);

     
     
      // Set scene and show window
      scene = new Scene(root, 400, 300);
      stage.setScene(scene);
      stage.show();      
   }
   
   public void handle(ActionEvent ae) {
      String command = ((Button)ae.getSource()).getText();
      
   }
   
   /** doRead - the Read button */
   private void doRead() {
          
   }
}