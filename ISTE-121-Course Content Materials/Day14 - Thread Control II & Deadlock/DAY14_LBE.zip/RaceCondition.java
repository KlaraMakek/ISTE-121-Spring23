import java.util.*;
import java.util.concurrent.locks.*;

public class RaceCondition {

    // attributes
    private int raceCount = 0;// multiple threads will add to this counter
    private ArrayList<Integer> raceList = new ArrayList<Integer>();
    // private Vector<Integer> raceList = new Vector<Integer>();//vector is
    // thread-save, arrayList is not

    private int MAX = 10000;// for each loop
    private int NUM_THREADS = 100; // number of threads

    // lock
    private Object publicLock = new Object();

    private Lock countReLock = new ReentrantLock();

    // constructor
    public RaceCondition() {

        ArrayList<Thread> arrayT = new ArrayList<Thread>();
        for (int i = 0; i < NUM_THREADS; i++) {
            Thread aTh = new RaceThread();
            aTh.setName("" + i);
            arrayT.add(aTh);
        }
        // start all threads
        for (int i = 0; i < arrayT.size(); i++) {
            arrayT.get(i).start();
        }
        for (int i = 0; i < arrayT.size(); i++) {
            try {
                arrayT.get(i).join();
            } catch (InterruptedException ie) {
                ie.printStackTrace();
            }
        }

        System.out.println("RaceCount:" + raceCount + ", should have: " + NUM_THREADS * MAX);
        System.out.println("raceList:" + raceList.size() + ", should have: " + NUM_THREADS * MAX);

    }

    // inner class for thread
    class RaceThread extends Thread {

        // lock
        private Object localLock = new Object();

        @Override
        public void run() {
            for (int i = 0; i < MAX; i++) {

                // case 1
                update(i);

                // case 2
                // update2(i);

                // case 3
                // update3(i);

            }
        }

        // case 1 - simple adding
        private void update(int i) {
            raceCount = raceCount + 1;
            raceList.add(i);
        }

        // Case 2 - synchronization
        private void update2(int i) {

            // synchronized (localLock) {//not ok
            // synchronized (this) {// not ok
            synchronized (publicLock) {// ok

                raceCount = raceCount + 1;
                raceList.add(i);// fddfdfdfdfdfdkjjkjlkjdlkgjdlfkgjdlfkgjldkjgldkjgdg
                // jsljfldkfjgldkfjgldkfjgldkfjgldgkfgkjfgfkdgldfjgldkfjgdlfkjgdfg
                // kjldkjgdlfkjgldfk//weeeeee//fgfPRTOOOj//PEROOO///
            }
        }

        // reentrant example
        public void update3(int i) {

            countReLock.lock();

            raceCount = raceCount + 1;
            raceList.add(i);

            countReLock.unlock();
        }
    }

    public static void main(String[] args) {
        new RaceCondition();
    }
}
