import java.io.*;
import java.util.*;
import java.util.Random;

public class StudentDatabaseCreate {

   private final static String OUTPUT_NAME = "STUDENTS";
   private DataOutputStream dos;
   NameGenerator nameGenerator = null;

   public static void main(String args[]) {
      new StudentDatabaseCreate();
   }

   StudentDatabaseCreate() {
      nameGenerator = new NameGenerator();

      int totalFiles = 20;
      int studentInFiles = 200000;
      for (int i = 0; i < totalFiles; i++) {
         String fileName = OUTPUT_NAME + (2000 + i) + ".bin";
         try {
            dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));

            for (int s = 0; s < studentInFiles; s++) {
               String name = nameGenerator.generateName();
               double grade = Math.random() * 100;
               dos.writeUTF(name);
               dos.writeDouble(grade);
               // System.out.println(OUTPUT_NAME+ (2000+i)+":" + name+", " + grade);
            }
            dos.flush();
         } catch (FileNotFoundException fnfe) {
            System.out.println("Trouble creating " + OUTPUT_NAME);// output for the user
            fnfe.printStackTrace();// this is used primarily for debugging - output for the developer
         } catch (IOException ioe) {
            ioe.printStackTrace();// this is used primarily for debugging - output for the developer
         } finally {
            try {
               if (dos != null)
                  dos.close();
            } catch (IOException ioe) {
            }
         }
      }
   }

   class NameGenerator {

      String[] Beginning = { "Kr", "Ca", "Ra", "Mrok", "Cru",
            "Ray", "Bre", "Zed", "Drak", "Mor", "Jag", "Mer", "Jar", "Mjol",
            "Zork", "Mad", "Cry", "Zur", "Creo", "Azak", "Azur", "Rei", "Cro",
            "Mar", "Luk" };
      String[] Middle = { "air", "ir", "mi", "sor", "mee", "clo",
            "red", "cra", "ark", "arc", "miri", "lori", "cres", "mur", "zer",
            "marac", "zoir", "slamar", "salmar", "urak" };
      String[] End = { "d", "ed", "ark", "arc", "es", "er", "der",
            "tron", "med", "ure", "zur", "cred", "mur" };

      Random rand = new Random();//

      public String generateName() {

         return Beginning[rand.nextInt(Beginning.length)] +
               Middle[rand.nextInt(Middle.length)] +
               End[rand.nextInt(End.length)];

      }

   }
}