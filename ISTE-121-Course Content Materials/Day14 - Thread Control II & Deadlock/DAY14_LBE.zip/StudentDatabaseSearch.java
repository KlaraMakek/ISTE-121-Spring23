import java.io.*;
import java.util.*;

public class StudentDatabaseSearch {

   private final static String OUTPUT_NAME = "STUDENTS";

   private ArrayList<String> studentNames = new ArrayList<String>();// final array of names
   private ArrayList<Double> studentGrades = new ArrayList<Double>();// final aray of grades
   private ArrayList<String> databaseNames = new ArrayList<String>();// final array of source files
   Object lock = new Object();

   public static void main(String args[]) {
      new StudentDatabaseSearch();
   }

   StudentDatabaseSearch() {
      // preparing threads
      // creating runnable threads - each thread demands FILEPATH and grande range
      double gradeRangeMin = 50;
      double gradeRangeMax = 55;

      long start = System.currentTimeMillis();

      ArrayList<Thread> myThreadList = new ArrayList<Thread>();// fgfg

      int totalFiles = 20;
      for (int i = 0; i < totalFiles; i++) {
         String fileName = OUTPUT_NAME + (2000 + i) + ".bin";
         // creating a thread
         Thread newThread1 = new SearchGrades(fileName, gradeRangeMin, gradeRangeMax);
         myThreadList.add(newThread1);
         newThread1.start();
         try {
            newThread1.join();
         } catch (InterruptedException ie) {
         }
      }

      // start all threads
      /*
       * for (int i = 0; i < myThreadList.size(); i++) {
       * myThreadList.get(i).start();
       * }
       * for (int i = 10; i < 19; i++) {
       * myThreadList.get(i).setPriority(10);
       * }
       * try {
       * for (int i = 0; i < myThreadList.size(); i++) {
       * myThreadList.get(i).join();
       * }
       * } catch (InterruptedException ie) {
       * }
       */

      // printing result
      // All is done, now we can print out the results!
      /*
       * System.out.println("Search result total " + studentNames.size() + ":");
       * for (int i = 0; i < studentNames.size(); i++) {
       * System.out.println(studentNames.get(i) + " " + studentGrades.get(i) + " in "
       * + databaseNames.get(i));
       * }
       */

      long finish = System.currentTimeMillis();
      long timeElapsed = finish - start;
      System.out.println("Elapsed time:" + timeElapsed / 1000.0 + "[s]");

   }

   class SearchGrades extends Thread {
      private String databaseName = "";
      private DataInputStream dis = null;
      private int counter = 0;
      private double gradeMin = 0;
      private double gradeMax = 0;

      public SearchGrades(String databaseName, double gradeMin, double gradeMax) {
         this.databaseName = databaseName;
         this.gradeMin = gradeMin;
         this.gradeMax = gradeMax;
      }

      @Override
      public void run() {
         System.out.println("Start thread:" + this.databaseName);
         try {
            dis = new DataInputStream(new BufferedInputStream(new FileInputStream(this.databaseName)));
            while (dis.available() > 0) {
               String name = dis.readUTF();
               double grade = dis.readDouble();
               if (grade >= gradeMin && grade <= gradeMax) {
                  synchronized (lock) {
                     studentNames.add(name);
                     studentGrades.add(grade);
                     databaseNames.add(this.databaseName);
                  }
               }
            }
         } catch (FileNotFoundException fnfe) {
            System.out.println("File " + databaseName + " not found.");
            return;
         } catch (IOException ioe) {
            System.out.println("IO Exception");
            ioe.printStackTrace();
         } finally {
            try {
               if (dis != null)
                  dis.close();
            } catch (IOException ioe) {
               ioe.printStackTrace();
            }
         }
         System.out.println("End thread:" + this.databaseName);
      }

   }

}