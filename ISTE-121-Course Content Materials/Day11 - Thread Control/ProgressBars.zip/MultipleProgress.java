import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;

public class MultipleProgress extends Application {
   // Window Attributes
   Stage stage;
   Scene scene;

   InnerProgress ip1 = new InnerProgress();
   InnerProgress ip2 = new InnerProgress();
   InnerProgress ip3 = new InnerProgress();

   /** main program */
   public static void main(String[] args) {
      launch(args);
   }

   /** constructor */
   public void start(Stage _stage) {
      stage = _stage;
      stage.setTitle("MultipleComponents");
   
      GridPane root = new GridPane();
      root.setAlignment(Pos.CENTER);
   
      root.add(ip1, 0, 1);
      root.add(ip2, 0, 2);
      root.add(ip3, 0, 3);
   
      Thread t1 = new Thread(ip1);
      Thread t2 = new Thread(ip2);
      Thread t3 = new Thread(ip3);
   
      t1.start();
      t2.start();
      t3.start();
   
      // Set scene and show window
      scene = new Scene(root, 150, 100);
      stage.setScene(scene);
      stage.show();
   }

   class InnerProgress extends FlowPane implements Runnable {
   
      private ProgressBar pbBar = new ProgressBar(0);
      private Label lblValue = new Label("0");
   
      public InnerProgress() {
         StackPane spBar = new StackPane();
         spBar.getChildren().addAll(pbBar, lblValue);
         this.getChildren().add(spBar);
      
      }
   
      public void run() {
         for (int i = 1; i <= 100; i++) {
            try {
               Thread.sleep((int) (Math.random() * 200));
            } catch (InterruptedException ie) {
            }
         
            final int finalI = i;
            Platform.runLater(
               new Runnable() {
                  public void run() {
                     pbBar.setProgress(finalI / 100.0);
                     lblValue.setText(finalI + "");
                     System.out.println(finalI);
                  }
               });
         
         }
      }
   }
}
