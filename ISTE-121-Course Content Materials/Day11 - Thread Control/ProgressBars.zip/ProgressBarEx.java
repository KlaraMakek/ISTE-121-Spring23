import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.util.*;

/**
 * Simple thread ... update a time counter while the user
 * types in data to store in a text file
 * 
 * @author Pete Lutz
 * @version 7-9-2018
 */

public class ProgressBarEx extends Application implements EventHandler<ActionEvent> {
   // Window attributes
   private Stage stage;
   private Scene scene;

   // GUI Components
   private Button btnClickMe = new Button("Click ME");
   private Label lblProgress = new Label("Progress: ");
   private Label lblValue = new Label("0");
   private ProgressBar pbBar = new ProgressBar(0);// ProgressBar.INDETERMINATE_PROGRESS

   // Timer for the ClickMe button
   java.util.Timer timer = null;

   /** main program */
   public static void main(String[] args) {
      launch(args);
   }

   /** constructor */
   public void start(Stage _stage) {
      // Setup window
      stage = _stage;
      stage.setTitle("ProgressBar");
   
      VBox root = new VBox(8);
   
      // Bottom top
      FlowPane fpTop = new FlowPane(8, 8);
      fpTop.setAlignment(Pos.CENTER);
      fpTop.getChildren().add(btnClickMe);
   
      // bottom
      FlowPane fpBot = new FlowPane(8, 8);
      fpBot.setAlignment(Pos.CENTER);
   
      StackPane spBar = new StackPane();
      spBar.getChildren().addAll(pbBar, lblValue);
      fpBot.getChildren().addAll(lblProgress, spBar);
   
      root.getChildren().addAll(fpTop, fpBot);
   
      // Set the scene and show the window
      scene = new Scene(root, 300, 75);
      stage.setScene(scene);
      stage.show();
   
      // events
      this.btnClickMe.setOnAction(this);
   }

   /** Button handler */
   public void handle(ActionEvent ae) {
      String label = ((Button) ae.getSource()).getText();
   
      switch (label) {
         case "Click ME":
            btnClickMe.setText("Cancel");
            
            //Java java.util.Timer is a utility class that can be used to schedule a thread to be executed at certain time in future. 
            timer = new java.util.Timer();
            TimerTask ttask = 
               new TimerTask() {
               // local attributes
                  int value = 0;
               
                  public void run() {
                     Platform.runLater(
                        new Runnable() {
                           public void run() {
                              System.out.println("Timer test");
                              value = value + 10;
                              pbBar.setProgress(value / 100.0);
                              lblValue.setText(value + "");
                           
                              if (value == 100) {
                                 btnClickMe.setText("Click ME");
                                 pbBar.setProgress(ProgressBar.INDETERMINATE_PROGRESS);
                                 timer.cancel();
                              }
                           }
                        //});
                  }
               };
         
            timer.scheduleAtFixedRate(ttask, 1000, 500);
         
            /*
             * Cannot implement directly, needs to be in a separate thread
             * for (int i = 0; i <= 100; i++) {
             * pbBar.setProgress(i / 100.0);
             * lblValue.setText(i + "");
             * System.out.println(i);
             * 
             * // let's add sleep
             * try {
             * Thread.sleep(20);
             * } catch (InterruptedException ie) {
             * ie.printStackTrace();
             * }
             * }
             */
            break;
      
         case "Cancel":
            btnClickMe.setText("Click ME");
            timer.cancel();
            break;
      }
   
   }

}
