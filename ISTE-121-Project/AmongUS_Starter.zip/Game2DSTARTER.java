import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.animation.*;
import java.io.*;
import java.util.*;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;

// pixel reader
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 * PackmanGEOStarter with JavaFX and Thread
 */

public class Game2DSTARTER extends Application {
   // Window attributes
   private Stage stage;
   private Scene scene;
   private StackPane root;

   private static String[] args;

   private final static String ICON_IMAGE = "amongus.png"; // file with icon for a racer
   private final static String ICON_IMAGE_RUNNERS = "amongusRunners.png"; // file with icon for a racer

   private ArrayList<ImposterRacer> allRacers = new ArrayList<>();

   private AnimationTimer timer; // timer to control animation

   boolean running = false, goNorth = false, goSouth = false, goEast = false, goWest = false;

   // background
   private MovableBackground movableBack = null;

   // background collision
   Image backgroundCollision = null;

   // main program
   public static void main(String[] _args) {
      args = _args;
      launch(args);
   }

   // start() method, called via launch
   public void start(Stage _stage) {
      // stage seteup
      stage = _stage;
      stage.setTitle("Game2D Starter");
      stage.setOnCloseRequest(
            new EventHandler<WindowEvent>() {
               public void handle(WindowEvent evt) {
                  System.exit(0);
               }
            });
   
      // root pane
      root = new StackPane();
   
      // create an array of Racers (Panes) and start
      initializeScene();
   }

   // start the race
   public void initializeScene() {
   
      // create racers
      for (int i = 0; i < 2; i++) {
         ImposterRacer racer = new ImposterRacer(i == 0);
         allRacers.add(racer);
      }
   
      // add background
      this.movableBack = new MovableBackground();
   
      root.getChildren().add(movableBack);
      for (int i = 0; i < allRacers.size(); i++) {
         root.getChildren().add(allRacers.get(i));
      }
   
      // display the window
      scene = new Scene(root, 800, 500);
      // scene.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
      stage.setScene(scene);
      stage.show();
   
      // events for keyboard
      scene.setOnKeyPressed(
            new EventHandler<KeyEvent>() {
               @Override
               public void handle(KeyEvent event) {
                  System.out.println(event);
                  switch (event.getCode()) {
                     case UP:
                        goNorth = true;
                        break;
                     case DOWN:
                        goSouth = true;
                        break;
                     case LEFT:
                        goWest = true;
                        break;
                     case RIGHT:
                        goEast = true;
                        break;
                     case SHIFT:
                        running = true;
                        break;
                  }
               }
            });
   
      scene.setOnKeyReleased(
            new EventHandler<KeyEvent>() {
            
               @Override
               public void handle(KeyEvent event) {
                  switch (event.getCode()) {
                     case UP:
                        System.out.println("DOWN DOWN");
                        goNorth = false;
                        break;
                     case DOWN:
                        goSouth = false;
                        break;
                     case LEFT:
                        goWest = false;
                        break;
                     case RIGHT:
                        goEast = false;
                        break;
                     case SHIFT:
                        running = false;
                        break;
                  }
               }
            });
   
      System.out.println("Starting race...");
   
      backgroundCollision = new Image("background.jpg");
   
      // Use an animation to update the screen
      timer = 
         new AnimationTimer() {
            public void handle(long now) {
               for (int i = 0; i < allRacers.size(); i++) {
                  allRacers.get(i).update();
               }
               movableBack.update();
            // System.out.println("He");
            }
         };
      timer.start();
   }

   /**
    * Racer creates the race lane (Pane) and the ability to
    * keep itself going (Runnable)
    */

   protected class MovableBackground extends Pane {
   
      private int moveX = 0;
      private int moveY = 0;
      private ImageView aPicView; // a view of the icon ... used to display and move the image
   
      public MovableBackground() {
         // Draw the icon for the racer
         aPicView = new ImageView("background.jpg");
         this.getChildren().add(aPicView);
      }
   
      public void update() {
         if (goNorth)
            moveY -= 10;
         if (goSouth)
            moveY += 10;
         if (goEast)
            moveX += 10;
         if (goWest)
            moveX -= 10;
         // aPicView.setTranslateX(-moveX);
         // aPicView.setTranslateY(-moveY);
      }
   }

   protected class ImposterRacer extends Pane {
      private int racePosX = 0; // x position of the racer
      private int racePosY = 0; // x position of the racer
      private boolean isMaster = false;
      private ImageView aPicView; // a view of the icon ... used to display and move the image
   
      public ImposterRacer(boolean isMaster) {
         // Draw the icon for the racer
         if (isMaster)
            aPicView = new ImageView(ICON_IMAGE);
         else
            aPicView = new ImageView(ICON_IMAGE_RUNNERS);
      
         this.getChildren().add(aPicView);
         this.isMaster = isMaster;
      }
   
      /**
       * update() method keeps the thread (racer) alive and moving.
       */
      public void update() {
      
         Color color = backgroundCollision.getPixelReader().getColor((int) racePosX, (int) racePosY);
         // System.out.println(color.getRed() + " " + color.getGreen() + " " +
         // color.getBlue());
      
         double speed = 10;
         if (color.getRed() < 0.5)
            speed = 3;
      
         if (this.isMaster == false) {
            racePosX += (int) (Math.random() * speed);
            racePosY += (int) (Math.random() * speed);
         } else {
            if (goNorth)
               racePosY -= speed;
            if (goSouth)
               racePosY += speed;
            if (goEast)
               racePosX += speed;
            if (goWest)
               racePosX -= speed;
         
         }
      
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
      
         // LIMIT
         if (racePosX > 800)
            racePosX = 0;
         if (racePosY > 500)
            racePosY = 0;
         if (racePosX < 0)
            racePosX = 0;
         if (racePosY < 0)
            racePosY = 0;
      
      } // end update()
   } // end inner class Racer
} // end class Races